#pragma once

#include <condition_variable>
#include <grpcpp/grpcpp.h>
#include <memory>
#include <numeric>
#include <thread>
#include <unistd.h>
#include <utility>
#include <filesystem>

#include "file_shard.h"
#include "mapreduce_spec.h"
#include "masterworker.grpc.pb.h"

#define SERVER_ALIVE true
#define HEARTBEAT_TIMEOUT 5

namespace fs = std::filesystem;

enum class WorkerStatus
{
    FREE,
    BUSY,
    DEAD
};

enum class WorkerType
{
    MAPPER,
    REDUCER
};

struct HeartbeatPayload
{
    std::string id;
    std::int64_t timestamp;
    WorkerStatus status;
};

class AsyncClientCall
{
public:
    bool is_map_job = true;
    grpc::ClientContext context;
    grpc::Status status;
    std::string worker_ip_address;

    virtual ~AsyncClientCall() = default;
};

class MapCall : public AsyncClientCall
{
public:
    masterworker::Map_Response result;
    std::unique_ptr<grpc::ClientAsyncResponseReader<masterworker::Map_Response>> map_response_reader;
};

class ReduceCall : public AsyncClientCall
{
public:
    masterworker::Reduce_Response result;
    std::unique_ptr<grpc::ClientAsyncResponseReader<masterworker::Reduce_Response>> reduce_response_reader;
};

class HeartbeatCall : public AsyncClientCall
{
public:
    masterworker::Heartbeat_Payload result;
    std::unique_ptr<grpc::ClientAsyncResponseReader<masterworker::Heartbeat_Payload>> heartbeat_response_reader;
};

/**
 * Worker Client class to communicate with worker class
 */
class WorkerClient
{
public:
    WorkerClient(const std::string &address, grpc::CompletionQueue *queue);

    void sendHeartbeat(int64_t current_time);

    bool receiveHeartbeat();

    void scheduleReduceJob(const MapReduceSpec &spec, const std::vector<std::string> &file_list, const std::string &output_file_location);

    void scheduleMapperJobs(const MapReduceSpec &spec, const FileShard &shard);
    ~WorkerClient()
    {
        heartbeat_queue->Shutdown();
    }

private:
    std::unique_ptr<masterworker::Map_Reduce::Stub> stub;
    grpc::CompletionQueue *queue;
    std::string worker_address;
    grpc::CompletionQueue *heartbeat_queue;

    void convertGrpcSpec(const FileShard &shard, masterworker::Partition *partition);
};

/**
 * Constructor for worker client, creates communication insecure channel for each worker.
 * @param address
 * @param queue
 */
WorkerClient::WorkerClient(const std::string &address, grpc::CompletionQueue *queue)
    : queue(queue), worker_address(address)
{
    std::cout << "Creating channel at " + address << std::endl;
    heartbeat_queue = new grpc::CompletionQueue();
    this->stub = masterworker::Map_Reduce::NewStub(grpc::CreateChannel(address, grpc::InsecureChannelCredentials()));
}

/**
 * Send Async Heartbeat Request to client to infer health. It sets deadline for HEARTBEAT_TIMEOUT 5 secs if worker
 * times out in any case
 * @param current_time
 */
void WorkerClient::sendHeartbeat(std::int64_t current_time)
{
    std::chrono::system_clock::time_point deadline = std::chrono::system_clock::now() + std::chrono::seconds(HEARTBEAT_TIMEOUT);
    auto call = new HeartbeatCall;
    call->worker_ip_address = this->worker_address;
    call->context.set_deadline(deadline);
    masterworker::Heartbeat_Payload payload;
    payload.set_id(this->worker_address);
    payload.set_status(masterworker::Heartbeat_Payload_Type_UNKNOWN);
    call->heartbeat_response_reader =
        stub->PrepareAsyncHeartbeat(&call->context, payload, heartbeat_queue);
    call->heartbeat_response_reader->StartCall();
    call->heartbeat_response_reader->Finish(&call->result, &call->status, (void *)call);
}

/**
 * Async Heartbeat response reader,
 * @return false if worker times out or is unreachable or any other communication case.
 */
bool WorkerClient::receiveHeartbeat()
{
    void *tag;
    bool ok = false;
    GPR_ASSERT(heartbeat_queue->Next(&tag, &ok));
    auto *call = static_cast<HeartbeatCall *>(tag);
    if (call->status.ok())
    {
        if (call->result.status() == masterworker::Heartbeat_Payload_Type_DEAD)
        {
            std::cerr << "Error " << call->worker_ip_address << " : Dead" << std::endl;
            delete call;
            return false;
        }
        delete call;
        return true;
    }
    std::cerr << "Error " << this->worker_address << " : " << call->status.error_message()
              << " details: " << call->status.error_details() << " status code: " << call->status.error_code() << " ok: "
              << call->status.ok() << std::endl;
    delete call;
    return false;
}

/**
 * Schedules Reduce Jobs to worker.
 * @param spec mapreduce ini file data structure.
 * @param file_list
 * @param output_file_location
 */
void WorkerClient::scheduleReduceJob(
    const MapReduceSpec &spec,
    const std::vector<std::string> &file_list,
    const std::string &output_file_location)
{
    masterworker::Reduce_Request reduce_request;
    reduce_request.set_uuid(spec.user);
    reduce_request.set_output_file(output_file_location);
    for (const auto &file : file_list)
    {
        auto f = reduce_request.add_file_list();
        f->append(file);
    }
    auto call = new ReduceCall;
    call->worker_ip_address = this->worker_address;
    call->reduce_response_reader =
        stub->PrepareAsyncReduce(&call->context, reduce_request, queue);
    call->is_map_job = false;
    call->reduce_response_reader->StartCall();
    call->reduce_response_reader->Finish(&call->result, &call->status, (void *)call);
}

/**
 * Convert FileShard struct to GRPC partition.
 * @param shard
 * @param partition
 */
void WorkerClient::convertGrpcSpec(const FileShard &shard, masterworker::Partition *partition)
{
    partition->set_shard_id(shard.shard_id);
    for (const auto &file : shard.split_file_list)
    {
        auto temp = partition->add_file_list();
        temp->set_filename(file.filename);
        temp->set_start_offset(file.offsets.first);
        temp->set_end_offset(file.offsets.second);
    }
}

/**
 * Schedules mapper job with Worker Client, similar to reduce, heartbeat etc
 * @param spec
 * @param shard
 */
void WorkerClient::scheduleMapperJobs(const MapReduceSpec &spec, const FileShard &shard)
{
    masterworker::Map_Request map_request;
    map_request.set_uuid(spec.user);
    map_request.set_partition_count(spec.output_files);
    auto s = map_request.add_shard();
    this->convertGrpcSpec(shard, s);
    auto call = new MapCall;
    call->worker_ip_address = worker_address;
    call->map_response_reader = stub->PrepareAsyncMap(&call->context, map_request, queue);
    call->is_map_job = true;
    call->map_response_reader->StartCall();
    call->map_response_reader->Finish(&call->result, &call->status, (void *)call);
}

struct Worker
{
    std::string worker_address;
    WorkerStatus status;
    WorkerType type;
    FileShard current_shard;
    std::shared_ptr<WorkerClient> client;
    std::map<std::string, std::vector<std::string>> output_reducer_location_map; // Which intermediate files will be used
    int current_output;
    bool dead_handled = false;
};

/* CS6210_TASK: Handle all the bookkeeping that Master is supposed to do.
        This is probably the biggest task for this project, will test your
   understanding of map reduce */
class Master
{

public:
    /* DON'T change the function signature of this constructor */
    Master(const MapReduceSpec &, const std::vector<FileShard> &);

    /* DON'T change this function's signature */
    bool run();
    ~Master()
    {
        server_state = !SERVER_ALIVE;
        cq_->Shutdown();
        cleanupFiles();
    }

private:
    /* NOW you can add below, data members and member functions as per the need of
     * your implementation*/

    grpc::CompletionQueue *cq_; // Map Reduce Work Assignment
    bool server_state = SERVER_ALIVE;

    MapReduceSpec mr_spec;

    // Worker Queue
    Worker dummy{};
    std::vector<Worker> workers{};
    std::mutex worker_queue_mutex;
    std::condition_variable condition_worker_queue;
    Worker *findWorkerByName(const std::string &name);
    std::vector<int> findWorkersByStatus(WorkerStatus status);

    // Heartbeat Stuff
    bool init_heartbeat = true;
    std::mutex heartbeat_mutex;
    std::condition_variable condition_heartbeat;
    void heartbeat();
    void handleDeadWorker(const std::string &worker);

    // Clean up Stuff
    std::mutex cleanup_mutex;
    std::condition_variable condition_cleanup;
    void cleanupFiles();

    // Operational metadata for both map reduce
    int completion_count;
    bool ops_completed = false;
    std::mutex ops_mutex;
    std::condition_variable condition_ops;

    // Map
    int assigned_shards;
    std::vector<FileShard> file_shards;
    std::vector<FileShard> missing_shards;
    std::vector<std::string> intermediate_files;
    void asyncMap();

    // Reduce
    int assigned_partitions;
    std::vector<std::string> output_files;
    std::vector<int> missing_output_files;
    void asyncReducer();
    std::vector<std::string> assignFilesToReducer(int output_id);
};

/**
 * Return list of Worker id with requested status,
 * `FREE OR BUSY OR DEAD`
 * @param status
 * @return list of Worker id with requested status
 */
std::vector<int> Master::findWorkersByStatus(WorkerStatus status)
{
    std::vector<int> result;
    for (int i = 0; i < workers.size(); i++)
    {
        if (workers[i].status == status)
        {
            result.push_back(i);
        }
    }
    return result;
}

/**
 * Return Worker id with requested Name,
 *
 * @param name
 * @return pointer for Worker with requested name or Null pointer if not found
 */
Worker *Master::findWorkerByName(const std::string &name)
{
    for (auto &worker : workers)
    {
        if (worker.worker_address == name)
            return &worker;
    }
    std::cerr << "Worker " << name << " not found" << std::endl;
    return nullptr;
}

/**
 * Constructor for Master,
 * Inits worker clients given spec file.
 * This is all the information your master will get from the
 * framework. You can populate your other class data members here if you want
 * @param mr_spec
 * @param file_shards
 */
Master::Master(const MapReduceSpec &mr_spec, const std::vector<FileShard> &file_shards)
    : mr_spec(mr_spec), file_shards(file_shards)
{
    cq_ = new grpc::CompletionQueue();
    for (const auto &endpoint : mr_spec.worker_endpoints)
    {
        dummy.worker_address = endpoint;
        dummy.status = WorkerStatus::FREE;
        dummy.type = WorkerType::MAPPER;
        dummy.client = std::make_shared<WorkerClient>(endpoint, cq_);
        workers.push_back(dummy);
    }
}

/* CS6210_TASK: Here you go. once this function is called you will complete
 * whole map reduce task and return true if succeeded */
/**
 * Brain of code ;)
 * Handles few things
 * 1. Creates Temp intermediate Dir
 * 2. Create Heartbeat thread for monitoring status of workers
 * 3. Assigns Workers Mapper, checks for dead worker and reassigns the work after cleanup.
 * 4. Creates mapping required for intermediate file to Output files.
 * 5. Assigns work to reducers and handle any dead reducers.
 * 6. Handles cleanup for intermediate files
 * @return true false based of worker update.
 */
bool Master::run()
{
    std::thread check_heartbeat_status(&Master::heartbeat, this);
#if __cplusplus >= 201703L
    fs::create_directory(TEMP_DIR);
    if (fs::is_directory(mr_spec.output_directory))
    {
        for (const auto &file : fs::directory_iterator(mr_spec.output_directory))
        {
            fs::remove(file.path());
        }
    }
#else
    auto dir_string = std::string("rm -rf ") + std::string(TEMP_DIR);
    system(dir_string.c_str());
    mkdir(TEMP_DIR, 0755);
#endif

    std::thread map_job(&Master::asyncMap, this);
    {
        std::unique_lock<std::mutex> lock_heartbeat(heartbeat_mutex);
        init_heartbeat = true;
        condition_heartbeat.wait(lock_heartbeat, [this]
                                 { return !init_heartbeat; });
    }
    bool shards_done = false;
    completion_count = assigned_shards = file_shards.size();
    while (!shards_done)
    {
        for (const auto &shard : file_shards)
        {
            int worker_index;
            {
                std::unique_lock<std::mutex> shards_lock(cleanup_mutex);
                // wait for cleanup mutex and free worker.
                condition_cleanup.wait(shards_lock, [this]
                                       { return !findWorkersByStatus(WorkerStatus::FREE).empty(); });
                worker_index = findWorkersByStatus(WorkerStatus::FREE)[0];
                if (workers[worker_index].status == WorkerStatus::DEAD)
                {
                    continue;
                }
                workers[worker_index].current_shard = shard;
                workers[worker_index].status = WorkerStatus::BUSY;
                assigned_shards--;
            }
            auto client = workers[worker_index].client.get();
            //  Adds Mapper Job
            std::cout << "Assigning Map Work of shard id " + std::to_string(shard.shard_id) + " to " +
                             workers[worker_index].worker_address
                      << std::endl;

            client->scheduleMapperJobs(mr_spec, workers[worker_index].current_shard);
        }
        {
            std::unique_lock<std::mutex> work_done_lock(ops_mutex);
            condition_ops.wait(work_done_lock);
            if (assigned_shards <= 0 && ops_completed)
                shards_done = true;
        }

        {
            std::unique_lock<std::mutex> shards_lock(cleanup_mutex);
            if (assigned_shards > 0 && !missing_shards.empty())
            {
                std::cout << "Reassigning work for " << missing_shards[0].shard_id << std::endl;
                file_shards.clear();
                file_shards.assign(missing_shards.begin(), missing_shards.end());
                missing_shards.clear();
                condition_cleanup.notify_one();
            }
        }
    }
    map_job.join();
    std::cout << "Map Done." << std::endl;

    for (auto &worker : workers)
    {
        if (worker.status == WorkerStatus::DEAD)
            continue;
        worker.status = WorkerStatus::FREE;
        worker.type = WorkerType::REDUCER;
    }
    ops_completed = false;

    std::thread reduce_job(&Master::asyncReducer, this);

    bool partition_done = false;
    completion_count = assigned_partitions = mr_spec.output_files;
    std::vector<int> output_vector(assigned_partitions);
    std::iota(output_vector.begin(), output_vector.end(), 0);
    while (!partition_done && assigned_partitions > 0)
    {
        for (auto &output_id : output_vector)
        {
            int worker_index;
            std::string output_file;
            {
                std::unique_lock<std::mutex> partition_lock(cleanup_mutex);
                condition_cleanup.wait(
                    partition_lock, [this]
                    { return !findWorkersByStatus(WorkerStatus::FREE).empty(); });
                worker_index = findWorkersByStatus(WorkerStatus::FREE)[0];
                if (workers[worker_index].status == WorkerStatus::DEAD)
                {
                    continue;
                }
                workers[worker_index].type = WorkerType::REDUCER;
                output_file =
                    mr_spec.output_directory + "/" + std::string("output_file_").append(std::to_string(output_id));
                workers[worker_index].output_reducer_location_map[output_file] = assignFilesToReducer(output_id);
                workers[worker_index].current_output = output_id;
                workers[worker_index].status = WorkerStatus::BUSY;
                assigned_partitions--;
            }
            condition_cleanup.notify_one();
            auto client = workers[worker_index].client.get();
            //  Adds Reducer Job
            std::cout << "Assigning Reduce Work " + output_file + " to " + workers[worker_index].worker_address
                      << std::endl;

            client->scheduleReduceJob(
                mr_spec, workers[worker_index].output_reducer_location_map[output_file], output_file);
        }
        {
            std::unique_lock<std::mutex> work_done_lock(ops_mutex);
            condition_ops.wait(work_done_lock);
            if (assigned_partitions <= 0 && ops_completed)
                partition_done = true;
        }

        {
            std::unique_lock<std::mutex> partition_lock(cleanup_mutex);
            if (assigned_partitions > 0 && !missing_output_files.empty())
            {
                std::cout << "Reassigning work for " + mr_spec.output_directory + "/" +
                                 std::string("output_file_")
                          << missing_output_files[0] << std::endl;
                output_vector.clear();
                output_vector.assign(missing_output_files.begin(), missing_output_files.end());
                missing_output_files.clear();
                condition_cleanup.notify_one();
            }
        }
    }

    reduce_job.join();

    {
        std::unique_lock<std::mutex> heartbeat_lock(heartbeat_mutex);
        server_state = !SERVER_ALIVE;
        condition_heartbeat.notify_all();
    }
    check_heartbeat_status.join();
    cleanupFiles();
    return true;
}

/**
 * Handles heartbeat checks
 * 1. While server is alive, sends heartbeat messages asynchronously and waits for response.
 * 2. If response times out or comes as dead, calls cleanup function and reassigns the work.
 */
void Master::heartbeat()
{
    while (server_state)
    {
        std::map<std::string, HeartbeatPayload> message_queue;
        auto current_time = std::chrono::system_clock::now().time_since_epoch().count();
        for (const auto &worker : workers)
        {
            auto client = worker.client.get();
            HeartbeatPayload temp_payload{};
            temp_payload.id = worker.worker_address;
            if (worker.status != WorkerStatus::DEAD)
            {
                client->sendHeartbeat(temp_payload.timestamp);
                message_queue[worker.worker_address] = temp_payload;
            }
        }

        for (auto &worker : workers)
        {
            auto client = worker.client.get();
            if (!client)
                continue;
            if (worker.status != WorkerStatus::DEAD)
            {
                bool status = client->receiveHeartbeat();
                if (!status)
                {
                    std::cerr << "Error " << worker.worker_address << " : Dead, cleaning up" << std::endl;
                    worker.status = WorkerStatus::DEAD;
                    handleDeadWorker(message_queue[worker.worker_address].id);
                }
            }
        }

        if (init_heartbeat)
        {
            {
                std::unique_lock<std::mutex> heartbeat_lock(heartbeat_mutex);
                init_heartbeat = false;
                condition_heartbeat.notify_one();
            }
        }

        auto end_time = std::chrono::system_clock::now().time_since_epoch().count();

        if (end_time - current_time < 1000 * 1000)
        {
            std::unique_lock<std::mutex> heartbeat_lock(heartbeat_mutex);
            sleep(1);
            condition_heartbeat.wait_for(heartbeat_lock, std::chrono::milliseconds(5 * 1000), [this]
                                         { return true; });
        }
    }
}

/**
 * Given worker, cleans up incomplete work for the worker and moves the file shards or output files back to pool for
 * assigning to other workers
 * @param worker address/id
 */
void Master::handleDeadWorker(const std::string &worker)
{
    std::cerr << "HANDLING DEAD WORKER......" + worker << std::endl;
    auto w = findWorkerByName(worker);
    if (!w)
        return;
    std::lock_guard<std::mutex> lockGuard(cleanup_mutex);
    auto client = w->client.get();
    if (!client)
    {
        condition_ops.notify_all();
        return;
    }
    if (w->type == WorkerType::MAPPER && !ops_completed)
    {
        missing_shards.push_back(w->current_shard);
        assigned_shards++;
    }
    else
    {
        missing_output_files.push_back(w->current_output);
        assigned_partitions++;
    }
    w->status = WorkerStatus::DEAD;
    cleanupFiles();
    condition_cleanup.notify_one();
    condition_ops.notify_all();
}

/**
 * Cleans up file if Server is alive and if there is any Dead worker in the list.
 * and also handles intermediate files cleanup during master's exit.
 */
void Master::cleanupFiles()
{
    if (!findWorkersByStatus(WorkerStatus::DEAD).empty() && server_state == SERVER_ALIVE)
    {
        for (auto i : findWorkersByStatus(WorkerStatus::DEAD))
        {
            if (workers[i].type == WorkerType::MAPPER && !workers[i].dead_handled)
            {
                auto worker_port =
                    workers[i].worker_address.substr(workers[i].worker_address.find_first_of(':'));
#if __cplusplus >= 201703L
                for (auto &file : fs::directory_iterator(TEMP_DIR))
                {
                    if (file.path().string().find(worker_port) != std::string::npos)
                        fs::remove(file);
                }
#else
                auto dir_string = std::string("rm -rf ") + TEMP_DIR + "/*_" + worker_port + ".txt";
                system(dir_string.c_str());
#endif
            }
            else
            {
                for (const auto &worker_location : workers[i].output_reducer_location_map)
                {
                    if (!workers[i].dead_handled)
#if __cplusplus >= 201703L
                        fs::remove(worker_location.first);
#else
                        remove(worker_location.first.c_str());
#endif
                }
            }
            workers[i].dead_handled = true;
        }
    }
    if (!server_state)
    {
#if __cplusplus >= 201703L
        fs::remove_all(TEMP_DIR);
#else
        auto dir_string = std::string("rm -rf ") + TEMP_DIR;
        system(dir_string.c_str());
#endif
    }
}

/**
 * Handles Async Responses for Mapper Requests and frees worker for other work and puts data back in the list
 */
void Master::asyncMap()
{
    void *tag;
    bool ok = false;
    while (cq_->Next(&tag, &ok))
    {
        auto call = static_cast<AsyncClientCall *>(tag);
        if (call->status.ok())
        {
            if (findWorkerByName(call->worker_ip_address)->status != WorkerStatus::DEAD)
            {
                {
                    std::lock_guard<std::mutex> worker_queue_lock(worker_queue_mutex);
                    for (auto &worker : workers)
                    {
                        if (worker.worker_address == call->worker_ip_address)
                        {
                            std::cout << call->worker_ip_address + " back to free." << std::endl;

                            worker.status = WorkerStatus::FREE;
                            completion_count--;
                            std::cout << call->worker_ip_address + " response received. Completion Count: " +
                                             std::to_string(completion_count) +
                                             " Assigned Work: " + std::to_string(assigned_shards)
                                      << std::endl;
                            break;
                        }
                    }
                    condition_worker_queue.notify_one();
                }
                if (call->is_map_job)
                {
                    auto map_call = dynamic_cast<MapCall *>(call);
                    for (const auto &file : map_call->result.file_list())
                    {
                        intermediate_files.push_back(file);
                    }
                }
                {
                    std::unique_lock<std::mutex> work_done_lock(ops_mutex);
                    if (completion_count == 0)
                    {
                        ops_completed = true;
                        condition_ops.notify_one();
                        break;
                    }
                }
            }
            condition_cleanup.notify_one();
        }
        delete call;
    }
}

/**
 * Similar to asyncMap, handles Reducer Responses.
 */
void Master::asyncReducer()
{
    void *tag;
    bool ok = false;
    while (cq_->Next(&tag, &ok))
    {
        auto call = static_cast<AsyncClientCall *>(tag);
        if (call->status.ok())
        {
            if (findWorkerByName(call->worker_ip_address)->status != WorkerStatus::DEAD)
            {
                {
                    std::lock_guard<std::mutex> worker_queue_lock(worker_queue_mutex);
                    for (auto &worker : workers)
                    {
                        if (worker.worker_address == call->worker_ip_address)
                        {
                            worker.status = WorkerStatus::FREE;
                            completion_count--;
                            std::cout << call->worker_ip_address + " response received. Completion Count: " +
                                             std::to_string(completion_count) +
                                             " Assigned Work: " + std::to_string(assigned_partitions)
                                      << std::endl;
                            break;
                        }
                    }
                    condition_worker_queue.notify_one();
                }
                if (!call->is_map_job)
                {
                    auto reduce_call = dynamic_cast<ReduceCall *>(call);
                    output_files.push_back(reduce_call->result.file_name());
                }
                {
                    std::unique_lock<std::mutex> work_done_lock(ops_mutex);
                    if (completion_count == 0)
                    {
                        ops_completed = true;
                        condition_ops.notify_one();
                        break;
                    }
                }
            }
            condition_cleanup.notify_one();
        }
        delete call;
    }
}

/**
 * Assigns list of intermediate files to output files for reducing
 * @param output_id
 * @return list of intermediate files for given output id /file
 */
std::vector<std::string> Master::assignFilesToReducer(int output_id)
{
    std::set<std::string> file_list;
    for (int i = 0; i < intermediate_files.size(); i++)
    {
        auto file = intermediate_files[i];
        if (i % mr_spec.output_files == output_id)
        {
            file_list.insert(file);
        }
    }
    std::vector<std::string> result(file_list.begin(), file_list.end());
    return result;
}